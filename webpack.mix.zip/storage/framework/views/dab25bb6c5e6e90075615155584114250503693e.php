<?php $__env->startSection('content'); ?>
<div class="card m-3">
    <a href="/submissions" class="m-3 btn btn-primary btn-large">Manage submissions</a>
</div>
<div class="card m-3">
    <a href="/inquiries" class="m-3 btn btn-primary btn-large">Manage inquiries</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\osp544\domains\german-pellets1.local\resources\views/dashboard.blade.php ENDPATH**/ ?>