 
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Submission ID: <?php echo e($submission->id); ?></h1>
</div>

<table class="table">
    <tbody>
            <tr>
                <th scope="col">Email</th>
                <td><?php echo e($submission->email); ?></td>
            </tr>
            <tr>
                <th scope="col">First Name</th>
                <td><?php echo e($submission->firstname); ?></td>
            </tr>
            <tr>
                <th scope="col">Last Name</th>
                <td><?php echo e($submission->lastname); ?></td>
            </tr>
            <tr>
                <th scope="col">Message</th>
                <td><?php echo e($submission->message); ?></td>
            </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\osp544\domains\german-pellets1.local\resources\views/submissions/show.blade.php ENDPATH**/ ?>