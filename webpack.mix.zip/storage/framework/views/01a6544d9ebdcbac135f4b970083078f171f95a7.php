 
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Submissions</h1>
</div>

<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Email</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
            <th scope="col">Message</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><a href="/submissions/<?php echo e($item->id); ?>"><?php echo e($item->id); ?></a></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->firstname); ?></td>
                <td><?php echo e($item->lastname); ?></td>
                <td><?php echo e($item->message); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($submissions->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\osp544\domains\german-pellets1.local\resources\views/submissions/index.blade.php ENDPATH**/ ?>