 
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Content</h1>
</div>

<div class="row">
    <p>Contacts Info</p>
    <form method="post" action="<?php echo e(route('content.store')); ?>">
        <?php echo csrf_field(); ?>
        <textarea rows="10" name="contacts" cols="80"><?php echo data_get($contacts, 'html_data'); ?></textarea>
        <div><input type="submit" value="Save Contacts"></div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\osp544\domains\german-pellets1.local\resources\views/content/index.blade.php ENDPATH**/ ?>