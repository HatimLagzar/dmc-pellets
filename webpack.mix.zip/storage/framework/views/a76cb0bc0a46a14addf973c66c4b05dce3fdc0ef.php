 
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Inquiry ID: <?php echo e($inquiry->id); ?></h1>
</div>

<table class="table">
    <tbody>
            <tr>
                <th scope="col">Email</th>
                <td><?php echo e($inquiry->email); ?></td>
            </tr>
            <tr>
                <th scope="col">First Name</th>
                <td><?php echo e($inquiry->firstname); ?></td>
            </tr>
            <tr>
                <th scope="col">Last Name</th>
                <td><?php echo e($inquiry->lastname); ?></td>
            </tr>
            <tr>
                <th scope="col">Address</th>
                <td><?php echo e($inquiry->address); ?></td>
            </tr>
            <tr>
                <th scope="col">Zip</th>
                <td><?php echo e($inquiry->zip); ?></td>
            </tr>
            <tr>
                <th scope="col">City</th>
                <td><?php echo e($inquiry->city); ?></td>
            </tr>
            <tr>
                <th scope="col">Phone</th>
                <td><?php echo e($inquiry->phone); ?></td>
            </tr>
            <tr>
                <th scope="col">Type</th>
                <td><?php echo e($inquiry->type); ?></td>
            </tr>
            <tr>
                <th scope="col">Quantity</th>
                <td><?php echo e($inquiry->quantity); ?></td>
            </tr>
            <tr>
                <th scope="col">Message</th>
                <td><?php echo e($inquiry->message); ?></td>
            </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\osp544\domains\german-pellets1.local\resources\views/inquiries/show.blade.php ENDPATH**/ ?>