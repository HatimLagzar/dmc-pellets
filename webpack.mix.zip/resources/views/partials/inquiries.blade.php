<div class="general-1 cb-section position-relative " style="" id="section_pos_90">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8" style="position: relative; ">
                <div class="row cb-section-mainrow">
                    <div class="col-12">
                        <div class="cb-section-block" style=" "><h2 class="ql-align-center"><font
                                    style="vertical-align: inherit;"><font style="vertical-align: inherit;">Send
                                        us your pellet inquiry now!</font></font></h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center cb-section-columnrow "
                     style="margin-top: -15px; margin-bottom: -15px;">
                    <div class="col-12 col-lg  " id="section_pos_90_column_pos_10"
                         style="margin-top: 15px; margin-bottom: 15px; ">
                        <div class="cb-column" style="height: 100%; position: relative;    ">
                            <div style="height: .1px;"></div>
                            <div class="cb-column-block" style="  ">
                                <form class="form-template-1 form--AnfrageFormular" action="/inquiries"
                                      method="post" enctype="multipart/form-data">
                                    <div style="display: none;">
                                        <label>
                                            Füllen Sie dies nicht aus, wenn Sie ein Mensch sind
                                            <input type="email" name="e_mail">
                                        </label>
                                    </div>
                                    <div class="form-group">
                                        <label for="Vorname-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Vorname-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">first
                                                        name</font></font></i>
                                        </label>
                                        <input type="text" class="form-control input-type-text"
                                               id="Vorname-da07cf54-7d30-477c-97aa-85397021b21f" name="Vorname"
                                               aria-describedby="Vorname-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                    </div>
                                    <div class="form-group">
                                        <label for="Nachname-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Nachname-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Surname</font></font></i>
                                        </label>
                                        <input type="text" class="form-control input-type-text"
                                               id="Nachname-da07cf54-7d30-477c-97aa-85397021b21f"
                                               name="Nachname"
                                               aria-describedby="Nachname-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                    </div>
                                    <div class="form-group">
                                        <label for="Strasse-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Strasse-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Street and house
                                                        number</font></font></i>
                                        </label>
                                        <input type="text" class="form-control input-type-text"
                                               id="Strasse-da07cf54-7d30-477c-97aa-85397021b21f" name="Strasse"
                                               aria-describedby="Strasse-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                    </div>
                                    <div class="form-group">
                                        <label for="Postleitzahl-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Postleitzahl-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">ZIP Code </font></font></i>
                                            <span class="text-danger"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">*</font></font></span>
                                        </label>
                                        <input class="form-control"
                                               id="Postleitzahl-da07cf54-7d30-477c-97aa-85397021b21f"
                                               name="Postleitzahl"
                                               aria-describedby="Postleitzahl-label-da07cf54-7d30-477c-97aa-85397021b21f"
                                               required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="Ort-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Ort-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">place </font></font></i>
                                            <span class="text-danger"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">*</font></font></span>
                                        </label>
                                        <input type="text" class="form-control input-type-text"
                                               id="Ort-da07cf54-7d30-477c-97aa-85397021b21f" name="Ort"
                                               aria-describedby="Ort-label-da07cf54-7d30-477c-97aa-85397021b21f"
                                               required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="Telefon-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Telefon-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">phone</font></font></i>
                                        </label>
                                        <input type="tel" class="form-control input-type-tel"
                                               id="Telefon-da07cf54-7d30-477c-97aa-85397021b21f" name="Telefon"
                                               aria-describedby="Telefon-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                    </div>
                                    <div class="form-group">
                                        <label for="Email-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Email-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">e-mail </font></font></i>
                                            <span class="text-danger"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">*</font></font></span>
                                        </label>
                                        <input type="email" class="form-control input-type-email"
                                               id="Email-da07cf54-7d30-477c-97aa-85397021b21f" name="Email"
                                               aria-describedby="Email-label-da07cf54-7d30-477c-97aa-85397021b21f"
                                               required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="Ware-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Ware-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                            <i><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Do you need loose
                                                        pellets or sacks?</font></font></i>
                                        </label>
                                        <select class="form-control" name="Ware"
                                                id="Ware-da07cf54-7d30-477c-97aa-85397021b21f"
                                                aria-describedby="Ware-label-da07cf54-7d30-477c-97aa-85397021b21f">
                                            <option value="Lose Pellets"><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Loose
                                                        pellets</font></font></option>
                                            <option value="Pellets in Säcken"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Pellets in bags</font></font>
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="Menge-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Menge-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Quantity </font></font><span
                                                    class="ql-size-small"><font
                                                        style="vertical-align: inherit;"><font
                                                            style="vertical-align: inherit;">(in tons or pallets)</font></font></span></i>
                                            <span class="text-danger"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;"> *</font></font></span>
                                        </label>
                                        <input type="number" class="form-control input-type-number"
                                               id="Menge-da07cf54-7d30-477c-97aa-85397021b21f" name="Menge"
                                               aria-describedby="Menge-label-da07cf54-7d30-477c-97aa-85397021b21f"
                                               required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="Nachricht-da07cf54-7d30-477c-97aa-85397021b21f"
                                               id="Nachricht-label-da07cf54-7d30-477c-97aa-85397021b21f"><i><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Your message to
                                                        us:</font></font></i>
                                        </label>
                                        <textarea class="form-control"
                                                  id="Nachricht-da07cf54-7d30-477c-97aa-85397021b21f"
                                                  name="Nachricht"
                                                  aria-describedby="Nachricht-label-da07cf54-7d30-477c-97aa-85397021b21f"
                                                  rows="3"></textarea>
                                    </div>
                                    <div>
                                        <button class="btn btn-lg btn-outline-primary mt-3 w-100" type="submit">
                                            <i><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Submit</font></font></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg  " id="section_pos_90_column_pos_20"
                         style="margin-top: 15px; margin-bottom: 15px; ">
                        <div class="cb-column" style="height: 100%; position: relative;    ">
                            <div style="height: .1px;"></div>
                            <div class="cb-column-block" style="  ">
                                <div class="cb-img-block" style="width:100%;"><img alt="DMC Pellets logo"
                                                                                   src="/images/DMC_LOGO.jpg"
                                                                                   class="lazyautosizes ls-is-cached lazyloaded"
                                                                                   style="width: 100%; height: auto; "
                                    >
                                </div>
                            </div>
                            <div class="cb-column-block" style="  padding-left:10px;"><h3>Contact</h3>
                                {!! $contacts_html_data !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
