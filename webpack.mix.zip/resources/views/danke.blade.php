@extends('layouts.dmc')

@section('content')
<main class="danke">
    <div id="main_10" class="Standard-1_mit_Standardbreite_8_12">
        <div class="general-1 cb-section position-relative " style="margin-top:50px;
background-image :linear-gradient(to top left, #E43E43 49%, #fff 51%);
width:100%;

height:50px;
padding:0px;" id="section_pos_10">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-8" style="position: relative; ">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="main_20" class="Standard-1_mit_Standardbreite_8_12">
        <div class="general-1 cb-section position-relative " style="background-color:#E43E43;
color:white;" id="section_pos_20">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-8" style="position: relative; ">
                        <div class="row cb-section-mainrow" style="padding-bottom: 0;">
                            <div class="col-12">
                                <div class="cb-section-block" style=" "><h2 class="ql-align-center"><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">Thank
                                                you for your inquiry!</font></font></h2>
                                    <p class="ql-align-center"><br></p><h4 class="ql-align-center"><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">We
                                                will contact you as soon as possible.</font></font></h4>
                                    <p class="ql-align-center"><br></p>
                                    <p class="ql-align-center"><a href="/"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">Back to Home
                                                    &gt;&gt;&gt;</font></font></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="main_25" class="Standard-1_mit_Standardbreite_8_12">
        <div class="general-1 cb-section position-relative " style="background-image :linear-gradient(to bottom right, #E43E43 49%, #fff 51%);
width:100%;
margin-bottom:50px;
height:50px;
padding:0px;" id="section_pos_25">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-8" style="position: relative; ">
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
