@extends('layouts.admin')

@section('content')
<div class="card m-3">
    <a href="/submissions" class="m-3 btn btn-primary btn-large">Manage submissions</a>
</div>
<div class="card m-3">
    <a href="/inquiries" class="m-3 btn btn-primary btn-large">Manage inquiries</a>
</div>
@endsection
